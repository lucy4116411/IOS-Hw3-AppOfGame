//
//  ViewController.swift
//  IOS-Hw3-00557127-Game App
//
//  Created by user on 2019/5/10.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

