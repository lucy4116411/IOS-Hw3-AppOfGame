//
//  ModeViewController.swift
//  IOS-Hw3-00557127-Game App
//
//  Created by user on 2019/6/2.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class ModeViewController: UIViewController {

    @IBOutlet weak var easyButton: UIButton!
    @IBOutlet weak var normalButton: UIButton!
    @IBOutlet weak var show: UILabel!
    @IBOutlet weak var hardButton: UIButton!
    @IBOutlet weak var GO: UIButton!
    var mode:Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.easyButton.transform = CGAffineTransform(translationX: 100, y: 0)
        },completion: nil)
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.normalButton.transform = CGAffineTransform(translationX: 0, y: -400.0)
        },completion: nil)
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.hardButton.transform = CGAffineTransform(translationX: 100, y: 0)
        },completion: nil)
        GO.isEnabled = false
        // Do any additional setup after loading the view.
    }
    @IBAction func normal(_ sender: Any) {
        mode = 1
        GO.isEnabled = true
        show.text = "Normal"
    }
    
    @IBAction func hard(_ sender: Any) {
        mode = 2
        GO.isEnabled = true
        show.text = "Hard"
    }
    @IBAction func easy(_ sender: Any) {
        mode = 0
        GO.isEnabled = true
        show.text = "Easy"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let des = segue.destination as? PlayViewController
        des?.mode = self.mode
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
