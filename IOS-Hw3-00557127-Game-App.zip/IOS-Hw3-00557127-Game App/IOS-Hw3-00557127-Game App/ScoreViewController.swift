//
//  ScoreViewController.swift
//  IOS-Hw3-00557127-Game App
//
//  Created by user on 2019/6/2.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class ScoreViewController: UIViewController {

    @IBOutlet weak var easyScore: UILabel!
    @IBOutlet weak var normalScore: UILabel!
    @IBOutlet weak var hardScore: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        var tmp:Int
        tmp = UserDefaults.standard.integer(forKey: "time0")
        easyScore.text = String(tmp) + " s"
        tmp = UserDefaults.standard.integer(forKey: "time1")
        normalScore.text = String(tmp) + " s"
        tmp = UserDefaults.standard.integer(forKey: "time2")
        hardScore.text = String(tmp) + " s"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
