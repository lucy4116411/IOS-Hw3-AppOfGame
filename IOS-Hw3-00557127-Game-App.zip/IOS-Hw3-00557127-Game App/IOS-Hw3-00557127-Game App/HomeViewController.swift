//
//  HomeViewController.swift
//  IOS-Hw3-00557127-Game App
//
//  Created by user on 2019/5/20.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit
import UserNotifications
import SafariServices
import AVFoundation

class HomeViewController: UIViewController {

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var ruleButton: UIButton!
    @IBOutlet weak var scoreButton: UIButton!
    var player:AVPlayer = AVPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let sendContent = UNMutableNotificationContent()
        sendContent.title = "快來上班囉"
        sendContent.subtitle = "小偷已經快要跑進來了ＱＱ"
        sendContent.body = "再不來準備扣薪水了好嗎？"
        sendContent.badge = 1
        sendContent.sound = UNNotificationSound.default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "notification1", content: sendContent, trigger: trigger)
        UNUserNotificationCenter.current().add(request,withCompletionHandler: nil)
        // Do any additional setup after loading the view.
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.playButton.transform = CGAffineTransform(translationX: 0, y: -400.0)
        },completion: nil)
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.ruleButton.transform = CGAffineTransform(translationX: 0, y: -300.0)
        },completion: nil)
        UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1, delay: 0, animations:{
            self.scoreButton.transform = CGAffineTransform(translationX: 0, y: -200.0)
        },completion: nil)
        let url = URL(string: "https://youtu.be/sdSwuDDMEzY")
        player = AVPlayer(url: url!)
        player.play()
    }
    
    @IBAction func infoClick(_ sender: Any) {
        if let url = URL(string: "https://medium.com/%E6%B5%B7%E5%A4%A7-ios-app-%E7%A8%8B%E5%BC%8F%E8%A8%AD%E8%A8%88"){
            let controller = SFSafariViewController(url: url)
            present(controller,animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
