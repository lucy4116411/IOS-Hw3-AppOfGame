//
//  PlayViewController.swift
//  IOS-Hw3-00557127-Game App
//
//  Created by user on 2019/5/26.
//  Copyright © 2019 alulu. All rights reserved.
//

// 0 = ghost
// 1 = ghost1
// 2 = police
// 3 = police1
// 4 = thief
// 5 = thief1
// 6 = ghost_s
// 7 = ghost1_s
// 8 = police_s
// 9 = police1_s
// 10 = thief_s
// 11 = thief1_s


import UIKit
import AudioToolbox

class PlayViewController: UIViewController {

    //var life:Int = 0
    
    @IBOutlet weak var clickButton: UIButton!
    @IBOutlet weak var playTime: UILabel!
    var changeTimer: Timer?
    var countTimer: Timer?
    var checkTimer: Timer?
    var heart : [UIImageView] = [UIImageView]()
    var timeScore:Int = 0
    var mode:Int=0
    var typeList:[String] = ["ghost","ghost1","police","police1","thief","thief1","ghost_s","ghost1_s","police_s","police1_s","thief_s","thief1_s"]
    var alive:Bool = true
    var timeInt:Double = 0
    let userDefaults = UserDefaults.standard
    
    class Item{
        var canTouch:Bool
        var type:Int
        var clicked:Bool
        init(){
            canTouch = false
            type = 0
            clicked = false
        }
        init(canTouch:Bool,type:Int){
            self.canTouch = canTouch
            self.type = type
            clicked = false
        }
        func change(canTouch:Bool,type:Int){
            self.canTouch = canTouch
            self.type = type
            clicked = false
        }
        func click(){
            clicked = true
        }
    }
    
    var showItem:Item = Item()
    
    @IBAction func touched(_ sender: UIButton) {
        if(showItem.canTouch==true){
            AudioServicesPlaySystemSound(1057)
        }
        else{
            AudioServicesPlaySystemSound(1009)
        }
        showItem.click()
    }
    func setItem(){
        let initRandom = Int.random( in: 0...11)
        print(initRandom)
        if (initRandom < 6) {
            showItem.change(canTouch: true, type: initRandom)
        }
        else{
            showItem.change(canTouch: false, type: initRandom)
        }
        clickButton.setImage(UIImage(named: typeList[initRandom]), for: .normal)
    }
    func backMode(){
        /*if let controllerBack = storyboard?.instantiateViewController(withIdentifier: "Mode"){
            present(controllerBack,animated: true,completion: nil)
        }*/
        _ = navigationController?.popViewController(animated: true)
    }
    func backHome(){
        /*if let controllerBack = storyboard?.instantiateViewController(withIdentifier: "Home"){
            present(controllerBack,animated: true,completion: nil)
        }*/
        _ = navigationController?.popToRootViewController(animated: true)
    }
    func alert(){
        let controller = UIAlertController(title: "ＱＱ 結束了", message:"你把重要的東西都趕跑了！" , preferredStyle: .alert)
        let restartAction = UIAlertAction(title:"再上班一次",style: .default){(_) in
            self.backMode()
        }
        let cancelAction = UIAlertAction(title: "下班囉", style: .cancel){
            (_)in
            self.backHome()
        }
        controller.addAction(restartAction)
        controller.addAction(cancelAction)
        present(controller,animated: true,completion: nil)
    }
    
    func activateTimer(){
        changeTimer = Timer.scheduledTimer(withTimeInterval: timeInt, repeats: true){(_) in
            if(self.alive == false){
                print("die")
                self.clickButton.isEnabled = false
                self.changeTimer?.invalidate()
                self.alert()
            }
            else{
                //self.timeScore+=1
                //self.playTime.text = String(self.timeScore) + " s"
                //print("change")
                if(self.showItem.clicked==false && self.showItem.canTouch==true){
                    self.heart[0].removeFromSuperview()
                    self.heart.remove(at: 0)
                    if(self.heart.count==0){
                        self.alive = false
                    }
                    else{
                        self.setItem()
                    }
                }
                else if(self.showItem.clicked==true && self.showItem.canTouch==false){
                    self.heart[0].removeFromSuperview()
                    self.heart.remove(at: 0)
                    if(self.heart.count==0){
                        self.alive = false
                    }
                    else{
                        self.setItem()
                    }
                }
                else{
                    self.setItem()
                }
            }
        }
        /*checkTimer = Timer.scheduledTimer(withTimeInterval: 0.95, repeats: true){(_) in
            print("check")
            if(self.showItem.clicked==false && self.showItem.canTouch==true){
                if(self.alive==true){
                    self.heart[0].removeFromSuperview()
                    self.heart.remove(at: 0)
                }
                else{
                    self.checkTimer?.invalidate()
                }
                if(self.heart.count==0){
                    self.alive = false
                }
            }
        }*/
        countTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true){(_) in
            if(self.alive == false){
                self.countTimer?.invalidate()
                let tmp = self.userDefaults.integer(forKey: "time"+String(self.mode))
                if (self.timeScore > tmp){
                    self.userDefaults.set(self.timeScore,forKey:"time"+String(self.mode))
                }
                print(self.userDefaults.integer(forKey: "time"+String(self.mode)))
            }
            else{
                self.timeScore+=1
                self.playTime.text = String(self.timeScore) + " s"
                
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        switch(mode){
        case 0:
            timeInt = 1.0
        case 1:
            timeInt = 0.85
        case 2:
            timeInt = 0.7
        default:
            timeInt = 1.0
        }
        playTime.text = "0 s"
        for i in 0...2{
            var image_heart:UIImageView
            let image = UIImage(named: "heart")!
            image_heart = UIImageView(image: image)
            image_heart.frame = CGRect(x: 250+i*50,y: 120,width: 29,height: 29)
            heart.append(image_heart)
            self.view.addSubview(image_heart)
        }

        setItem()
        activateTimer()
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
